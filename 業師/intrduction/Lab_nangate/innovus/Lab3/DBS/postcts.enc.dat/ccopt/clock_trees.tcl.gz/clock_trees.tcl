# ccopt saved state clock_trees.tcl.gz

create_ccopt_clock_tree -name CLK1 -source CLK -no_skew_group 
